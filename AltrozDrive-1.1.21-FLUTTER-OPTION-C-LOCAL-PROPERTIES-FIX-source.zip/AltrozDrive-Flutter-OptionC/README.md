# AltrozDrive — Option C Flutter migration

This project is the expanded Flutter screen implementation based on the latest available production reference:

`AltrozDrive-1.1.20-CREAM-GOLD-UI-CONSISTENCY-source.zip`

It replaces the earlier UI prototype with a multi-file Flutter application, a standard Android Flutter host, reusable design components, and coverage for the app's main tabs and all existing detail-screen destinations identified in `MainActivity.kt`.

## Visual direction

- Premium cream / warm-neutral surfaces, restrained gold accents and clear semantic colors.
- The existing high-resolution transparent Altroz vehicle cutout is used in the Home hero.
- Shared rounded metric cards, padding, headings and status pills across screens.
- Dark automotive panels for the Home hero, live speed gauge, fuel overview and Music player.
- No Home Navigation/LibreMap shortcut card was added; route maps are still represented on the dedicated Navigation screen.
- Trip screen separates `Recent (5)` and `History`.

## Included Flutter screens

1. First-launch setup / permission sequence
2. Home dashboard
3. Drive / live gauge and trip computer
4. Trips — Recent (5), History and related summaries
5. Fuel — selectable 7-day / 30-day / 90-day / 6-month periods
6. More menu
7. Vehicle profile
8. Music player
9. Navigation / route map
10. Data & History
11. Settings — appearance, accent and units
12. About AltrozDrive
13. Vehicle reminders — insurance and PUC dates
14. Driving insights
15. Fuel intelligence
16. Vehicle trends
17. Since last drive
18. Trip details (migrated version of the original trip details dialog)

All screens share the same design primitives. Screen navigation and local settings/date preferences are wired. Existing telemetry, trip values and route histories are not fabricated: until the corresponding repository/service migration exists, their UI clearly shows the unavailable state.

## Current status — important

**This is a complete screen-layer implementation pass, not yet a behavior-complete Option C migration.** It is not safe to replace the production 1.1.20 app with this build yet.

The original Kotlin and Java source is copied under `android/legacy_kotlin_reference/` strictly as a read-only reference. It is not compiled into the Flutter app. The following still need parity implementation and test vectors before the Option C migration is functionally complete:

- Classic Bluetooth/RFCOMM + HTS transport, ConnectNext peer-19 negotiation, watchdog/deadline/reconnect behavior and background lifecycle.
- Vehicle packet decoding, UID/VC selection, packet reassembly and all signal mappings.
- Database schema/version-10 migration, trip/telemetry repositories, deduplication, short-trip handling, 6-month retention and backup/restore.
- Trip boundary behavior, GPS sampling, route persistence, MapLibre/OpenRouteMap parity and trip detail data.
- Android media notification-listener integration and playback/seek control.
- Reminder notifications, boot/reboot scheduling and permission parity.

The screens deliberately show unavailable values until those integrations are real. A polished empty state is safer than demo numbers that may be mistaken for car telemetry.

## Testing environment

Flutter and Dart were not installed in the implementation environment, so `flutter pub get`, `flutter analyze`, `flutter test`, an APK build and device installation could not be run. Use a machine with Flutter stable and Android SDK configured. **Do not run Gradle sync before configuring the Flutter SDK.** From the `AltrozDrive-Flutter-OptionC` project root, run:

```bash
flutter doctor
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
```

If you are opening the project directly in Android Studio or running Gradle without the Flutter CLI, create `android/local.properties` (this file is machine-specific and must not be committed) with your actual paths, for example:

```properties
flutter.sdk=/absolute/path/to/flutter
sdk.dir=/absolute/path/to/Android/Sdk
```

On Windows, use escaped backslashes or forward slashes, e.g. `flutter.sdk=C:/src/flutter`. You can also set `FLUTTER_ROOT` for the Flutter SDK fallback. The Gradle settings now reports these setup steps clearly when the SDK path is missing; it cannot guess the Flutter SDK path on another machine.

The Android debug build uses the separate application ID `com.altrozdrive.app.fluttertest` so it can be installed alongside the existing app and cannot overwrite its private database. The release application ID is `com.altrozdrive.app`; **do not build or install a release build over 1.1.20 until data migration and all behavior parity tests have passed.**

## Migration integrity rules

- Do not alter the original source reference files when porting behavior.
- Do not change the protocol/peer-19 semantics, decoded values, trip start/end rules, GPS sample policy, or database behavior as a side effect of UI work.
- For each subsystem, record input/output parity against the original source before replacing it.
- If the full Dart transport layer cannot achieve RFCOMM/HTS parity, stop rather than shipping a superficially working UI; evaluate Option B as the agreed fallback.
